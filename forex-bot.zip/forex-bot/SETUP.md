# 🤖 Forex AI Bot — Complete Setup Gids

## Wat doet deze bot?
- Monitort 8 major forex paren 24/7
- Analyseert de markt met technische indicatoren (RSI, MACD, Bollinger Bands, etc.)
- Gebruikt Claude AI om buy/sell signalen te genereren met uitleg
- Stuurt berichten naar jouw Telegram met entry, stop-loss en take-profit
- Past de scanfrequentie aan op de beste handelssessies

---

## Stap 1: Telegram Bot aanmaken (5 minuten)

1. Open Telegram en zoek naar **@BotFather**
2. Stuur: `/newbot`
3. Kies een naam, bv: `Mijn Forex Bot`
4. Kies een gebruikersnaam, bv: `mijn_forex_bot`
5. Je krijgt een **token** — bewaar deze! Ziet eruit als: `1234567890:ABCdef...`

**Jouw Chat ID vinden:**
1. Stuur een bericht naar **@userinfobot** op Telegram
2. Je krijgt je `id` — dat is jouw Chat ID

---

## Stap 2: Groq API Key (100% gratis)

1. Ga naar https://console.groq.com
2. Maak een gratis account aan
3. Ga naar **API Keys** → **Create API Key**
4. Bewaar de key — ziet eruit als: `sk-ant-...`

> 💡 Volledig gratis. Groq geeft 14.400 gratis requests per dag — ruim voldoende voor 24/7 monitoring.

---

## Stap 3: Bot deployen op Railway (gratis)

### Optie A: Railway (aanbevolen — gratis $5/maand credits)

1. Maak account op https://railway.app (gratis)
2. Klik **New Project → Deploy from GitHub**
3. Upload de bestanden naar een nieuw GitHub repo
4. Voeg Environment Variables toe:
   ```
   TELEGRAM_TOKEN     = jouw_telegram_token
   TELEGRAM_CHAT_ID   = jouw_chat_id
   GROQ_API_KEY       = jouw_groq_key
   ```
5. Railway start de bot automatisch!

### Optie B: Lokaal draaien (voor testen)

```bash
# 1. Python venv aanmaken
python -m venv venv
source venv/bin/activate  # Mac/Linux
venv\Scripts\activate     # Windows

# 2. Packages installeren
pip install -r requirements.txt

# 3. .env bestand aanmaken
cp .env.example .env
# Vul je gegevens in in .env

# 4. Bot starten
python bot.py
```

---

## Stap 4: Bot testen

Open Telegram en stuur naar jouw bot:
- `/start` — Bot activeren
- `/status` — Huidige sessie en status zien
- `/scan` — Directe marktscan uitvoeren (test dit eerst!)
- `/pairs` — Welke paren worden gemonitord

---

## Scanfrequentie

| Sessie | Tijden (UTC) | Scan interval |
|--------|-------------|---------------|
| 🔥 London + NY overlap | 13:00–17:00 | Elke 15 min |
| 🇬🇧 London | 08:00–13:00 | Elke 20 min |
| 🗽 New York | 17:00–22:00 | Elke 20 min |
| 🗼 Tokyo | 00:00–09:00 | Elke 30 min |
| 😴 Rustig | 22:00–00:00 | Elke 60 min |

---

## Voorbeeld Telegram bericht

```
🟢 BUY SIGNAAL — EURUSD
━━━━━━━━━━━━━━━━━━
💰 Entry: 1.08450
🛑 Stop Loss: 1.08200
🎯 Take Profit: 1.08900
⚖️ Risk/Reward: 1.8:1
⏱ Tijdframe: korte termijn (1-4u)
💪 Signaalsterkte: 82/100
🟢 Betrouwbaarheid: HOOG
━━━━━━━━━━━━━━━━━━
📋 Reden: RSI keert om vanuit oversold zone met bullish MACD crossover

🔍 Analyse:
De RSI staat op 31 en draait omhoog vanuit oversold territory, wat historisch
een sterk koopmomentsignaal is. De MACD histogram toont een positieve crossover
terwijl de prijs de Bollinger onderband raakt als dynamische support...

⚠️ Geen financieel advies. Trade op eigen risico.
```

---

## Bestanden overzicht

```
forex-bot/
├── bot.py          # Hoofdbot + Telegram handlers
├── analyzer.py     # Technische analyse + AI
├── scheduler.py    # Handelssessie timing
├── requirements.txt
├── Procfile        # Voor Railway/Render hosting
├── runtime.txt     # Python versie
├── .env.example    # Voorbeeld environment vars
└── .gitignore
```

---

## ⚠️ Disclaimer

Deze bot is voor educatieve doeleinden. Forex trading brengt risico's met zich mee.
Trade nooit meer dan je kunt verliezen. De AI-analyse is geen gegarandeerd financieel advies.
